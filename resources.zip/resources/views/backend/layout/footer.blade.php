<footer class="footer footer-static footer-dark mt-3">
    <p class="clearfix mb-0"><span class="float-md-start d-block d-md-inline-block mt-25">ADMIN &copy; Solar<span
                class="d-none d-sm-inline-block">, All rights Reserved</span></span><span
            class="float-md-end d-none d-md-block"><i data-feather="heart"></i></span></p>
</footer>