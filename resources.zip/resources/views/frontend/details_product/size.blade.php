<section id="size">
    <div class="product-size__title">Kích thước gọng kính</div>
    <div class="product-size col-12">
        <div class="product-size__item">
            <img class="product-size__image" src="{{asset('assets/images/chieu_ngang.png')}}">
            <p class="product-size__info"></p>
        </div>
        <div class="product-size__item">
            <img class="product-size__image" src="{{asset('assets/images/chieu_ngang.png')}}">
            <p class="product-size__info">145mm</p>
        </div>
        <div class="product-size__item">
            <img class="product-size__image" src="{{asset('assets/images/chieu_ngang.png')}}">
            <p class="product-size__info">40mm</p>
        </div><div class="product-size__item">
            <img class="product-size__image" src="{{asset('assets/images/chieu_ngang.png')}}">
            <p class="product-size__info"></p>
        </div><div class="product-size__item">
            <img class="product-size__image" src="{{asset('assets/images/chieu_ngang.png')}}">
            <p class="product-size__info">20mm</p>
        </div>
    </div>
</section>