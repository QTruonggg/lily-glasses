<section id="info_img">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="main-detail">
                    <p>
                        <img style="display: block; margin-left: auto; margin-right: auto;" src="https://cdn.kinhmatlily.com/lily01/2023/1/nhựa-1672903120000.png" alt="nhựa.png" width="963" height="911">
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>