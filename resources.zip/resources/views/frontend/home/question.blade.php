<section id="question">
    <div class="container">
         <div class="row  gx-0">
            <div class="col-md-6 col-sm-6 col-sm-6">
               <div class="question-list">
                    <div class="cat-title">
                        <span>Kính mắt SOLAR có phải là sự lựa chọn đúng đắn ?</span>
                    </div>
                    <div class="cat-item">
                        <div class="row gx-3 gy-2">
                            <div class="col-md-6 col-sm-6 col-6">
                                <div class="wrap position-relative mb-2">
                                    <a class="cat-img d-block">
                                        <img src="{{asset('assets/images/trong-kinh.jpg')}}" alt="">
                                    </a>
                                    <div class="cat-info position-absolute">
                                        <h4>Đội ngũ Bác sĩ và Cử nhân Khúc xạ nhãn khoa Đại học Y Hà Nội có trình độ chuyên môn cao.</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-6">
                                <div class="wrap position-relative mb-2">
                                    <a class="cat-img d-block">
                                        <img src="{{asset('assets/images/trong-kinh.jpg')}}" alt="">
                                    </a>
                                    <div class="cat-info position-absolute">
                                        <h4>Đội ngũ Bác sĩ và Cử nhân Khúc xạ nhãn khoa Đại học Y Hà Nội có trình độ chuyên môn cao.</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-6">
                                <div class="wrap position-relative mb-2">
                                    <a class="cat-img d-block">
                                        <img src="{{asset('assets/images/trong-kinh.jpg')}}" alt="">
                                    </a>
                                    <div class="cat-info position-absolute">
                                        <h4>Đội ngũ Bác sĩ và Cử nhân Khúc xạ nhãn khoa Đại học Y Hà Nội có trình độ chuyên môn cao.</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-6">
                                <div class="wrap position-relative mb-2">
                                    <a class="cat-img d-block">
                                        <img src="{{asset('assets/images/trong-kinh.jpg')}}" alt="">
                                    </a>
                                    <div class="cat-info position-absolute">
                                        <h4>Đội ngũ Bác sĩ và Cử nhân Khúc xạ nhãn khoa Đại học Y Hà Nội có trình độ chuyên môn cao.</h4>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
               </div>
            </div>
             <div class="col-md-6 col-sm-6 col-sm-6">
                <div class="question-logo">
                    <img src="{{asset('assets/images/trong-kinh.jpg')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</section>