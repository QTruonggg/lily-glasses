<div class="col-md-12 col-sm-12 col-12 d-flex justify-content-center mt-3">
    <div class="b-center d-inline-block text-center" style="padding:5px 15px; border:1px solid rgb(0, 0, 0);">
        <a style="color:#333; text-decoration:none;" class="title-readmore" href="{{route('products')}}">Xem tất cả 
            <i class="fa-solid fa-chevron-right"></i>
        </a>
    </div>
</div>
